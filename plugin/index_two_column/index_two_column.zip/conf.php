<?php

return 	array (
	'name' => '首页两列',			// 插件名
	'brief' => '最新主题 + 精华主题。',
	'version' => '1.0.0',			// 插件版本
	'bbs_version' => '2.0.2',		// 插件支持的 Xiuno BBS 版本
);
?>