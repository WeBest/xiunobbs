<?php

return 	array (
	'name' => 'QQ登陆',		// 插件名
	'brief' => '一键QQ登陆。',
	'version' => '1.0.0',		// 插件版本
	'bbs_version' => '2.0.3',		// 插件支持的 Xiuno BBS 版本
);
?>