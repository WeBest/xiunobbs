<?php

return 	array (
	'name' => '主题列表 new fire 图标',			// 插件名
	'brief' => '在主题列表后显示 new, fire icon，增强版块活跃气氛。',
	'version' => '1.0.0',			// 插件版本
	'bbs_version' => '2.0.3',		// 插件支持的 Xiuno BBS 版本
);
?>