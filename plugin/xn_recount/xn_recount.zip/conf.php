<?php

return 	array (
	'name' => '重新统计',			// 插件名
	'brief' => '重新统计版块的主题数，回复数，精华数，用户的主题数，发帖数，精华数。',
	'version' => '1.0.1',			// 插件版本
	'bbs_version' => '2.0.3',		// 插件支持的 Xiuno BBS 版本
);
?>