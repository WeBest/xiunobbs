<?php

return 	array (
	'name' => 'Xiuno Shop',		// 插件名
	'brief' => '基于 Xiuno BBS 的简易的购物系统。',
	'version' => '1.0.0',		// 插件版本
	'bbs_version' => '2.1.0',		// 插件支持的 Xiuno BBS 版本
);
?>
