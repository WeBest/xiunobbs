<?php

header("Location:?friendlink-list.htm");

?>