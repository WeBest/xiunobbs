<?php

$this->location($this->url("friendlink-list.htm"));

?>