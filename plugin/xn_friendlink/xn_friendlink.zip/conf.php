<?php

return 	array (
	'name' => '友情链接',		// 插件名
	'brief' => '友情链接。',
	'version' => '1.0.0',		// 插件版本
	'bbs_version' => '2.0.2',		// 插件支持的 Xiuno BBS 版本
);
?>