<?php

return 	array (
	'name' => 'BT之家风格',		// 插件名
	'brief' => '宽屏风格+头部搜索+广告位+LOGO， LOGO 修改地址：plugin/view_btbbt/logo.gif',
	'version' => '1.0.0',		// 插件版本
	'bbs_version' => '2.0.2',		// 插件支持的 Xiuno BBS 版本
	'cateid' => 1,
	'styleid' => 0,
	'pluginid' => 71,
);
?>